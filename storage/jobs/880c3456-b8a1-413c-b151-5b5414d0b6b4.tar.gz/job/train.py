#!/usr/bin/env python3
"""
Exemple de script d'entraînement PyTorch simple.
"""
import os
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import numpy as np
import time

# Logique de sélection du device améliorée
if hasattr(torch.backends, "mps") and torch.backends.mps.is_available() and torch.backends.mps.is_built():
    device = torch.device("mps")
elif torch.cuda.is_available():
    device = torch.device("cuda")
else:
    device = torch.device("cpu")

print(f"Utilisation de: {device}")

def generate_data(n_samples=1000, n_features=20):
    X = np.random.randn(n_samples, n_features).astype(np.float32)
    w = np.random.randn(n_features).astype(np.float32)
    y = (np.dot(X, w) > 0).astype(np.float32)
    return X, y

# Définir un modèle simple
class SimpleModel(nn.Module):
    def __init__(self, input_dim):
        super(SimpleModel, self).__init__()
        self.layer1 = nn.Linear(input_dim, 64)
        self.layer2 = nn.Linear(64, 32)
        self.layer3 = nn.Linear(32, 1)
        
    def forward(self, x):
        x = torch.relu(self.layer1(x))
        x = torch.relu(self.layer2(x))
        x = torch.sigmoid(self.layer3(x))
        return x

def main():
    print("Starting training...")
    start_time = time.time()
    
    X, y = generate_data(n_samples=1000, n_features=20)
    X_tensor = torch.tensor(X)
    y_tensor = torch.tensor(y).reshape(-1, 1)
    
    dataset = TensorDataset(X_tensor, y_tensor)
    dataloader = DataLoader(dataset, batch_size=64, shuffle=True)
    

    model = SimpleModel(input_dim=20).to(device)

    criterion = nn.BCELoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    
    n_epochs = 5
    for epoch in range(n_epochs):
        model.train()
        total_loss = 0
        
        for batch_X, batch_y in dataloader:
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)
            
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            
            total_loss += loss.item()
        
        avg_loss = total_loss / len(dataloader)
        print(f"Epoch {epoch+1}/{n_epochs}, Loss: {avg_loss:.4f}")
    

    torch.save(model.state_dict(), "model.pt")
    
    training_time = time.time() - start_time
    print(f"Entraînement terminé en {training_time:.2f} secondes")
    print(f"Modèle sauvegardé: model.pt")
    
    model.eval()
    with torch.no_grad():
        test_X = torch.tensor(X[:10]).to(device)
        predictions = model(test_X)
        print("Prédictions sur 10 exemples:")
        print(predictions.cpu().numpy())

if __name__ == "__main__":
    main()